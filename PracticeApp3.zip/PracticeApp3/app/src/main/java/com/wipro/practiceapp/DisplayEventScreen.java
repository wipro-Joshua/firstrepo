package com.wipro.practiceapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import static android.R.id.list;

/**
 * Created by JO391061 on 08/10/2017.
 */

public class DisplayEventScreen extends AppCompatActivity {


    private static final String TAG = "DisplayEventScreen";

    Database db;
    String pasID = null;
    EventDetails details;



    EventListAdapter adapter;
    List<EventDetails> eventlist ;



    TextView title_text, id_text;
    EditText rTitle, rType, rLoc, rDate, rStatus;

    //Set String
    String s_Title, s_Type, s_Loc, s_date, s_Status;
    Button btn_delete, btn_edit;

    //ID
    private int selectedID;


    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.display_events_activity);



        // Set Text Views
        title_text = (TextView)findViewById(R.id.TitleTEXT);
        id_text = (TextView)findViewById(R.id.id_Text);
        rTitle = (EditText) findViewById(R.id.recevied_Title);
        rType = (EditText)findViewById(R.id.recevied_Type);
        rLoc = (EditText)findViewById(R.id.recevied_Loc);
        rDate = (EditText)findViewById(R.id.recevied_Date);
        //rStatus = (TextView)findViewById(R.id.recevied_Title);



        //Set Buttons
        btn_delete = (Button)findViewById(R.id.btn_DELETE);
        btn_edit = (Button)findViewById(R.id.btn_edit);


        //Open Database Connection
        db = new Database(this);

        Intent intent = getIntent();
        selectedID = intent.getIntExtra("ID", -1); //-1 is default value
        s_Title = intent.getStringExtra("Title");
        s_Type = intent.getStringExtra("Type");
        s_Loc = intent.getStringExtra("Loc");
        s_date = intent.getStringExtra("Date");


      /*  if(intent != null){
            pasID = intent.getStringExtra("ID");
            s_Title = intent.getStringExtra("Title");
            s_Type = intent.getStringExtra("Type");
            s_Loc = intent.getStringExtra("Loc");
            s_date = intent.getStringExtra("Date");
        }*/


        //Set Data
        title_text.setText(s_Title);
        rTitle.setText(s_Title);
        rType.setText(s_Type);
        rLoc.setText(s_Loc);
        rDate.setText(s_date);
        // rStatus.setText();


        //Calling methods

        EditEvent();
        DeleteEvent();


    }

    public void EditEvent(){btn_edit.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            String Title = rTitle.getText().toString();
            String Type = rType.getText().toString();
            String Location = rLoc.getText().toString();
            String Date =rDate.getText().toString();

            if(Title.equals("") || Type.equals("") || Location.equals("") || Date.equals("")){
                db.updateEvent(selectedID, Title, Type,Location,Date, s_Title, s_Type,s_Loc,s_date);

            }else {
                ToastMessage("Please Fill all fields");
            }

        }
        //Get Data and Update

    });
    }

    public void DeleteEvent(){btn_edit.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            db.deleteEvent3(selectedID, s_Title);
            ToastMessage("Deleted");


        }
        //Get Data and Update

    });
    }




    //Delete Event test1
    /*public void DeleteEvent(){
        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int id = Integer.parseInt(pasID);

                EventDetails details = eventlist.get(Integer.parseInt(pasID));

                db.deleteEvent(details);
                eventlist.remove(id);

                ToastMessage(s_Title + " Deleted");
                Intent goToStart = new Intent(DisplayEventScreen.this, MainActivity.class);
                startActivity(goToStart);

            }
        });}*/






    public void ToastMessage(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
