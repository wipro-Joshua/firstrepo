package com.wipro.practiceapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.nfc.Tag;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by JO391061 on 05/10/2017.
 */

public class Database extends SQLiteOpenHelper{

    private static final String TAG = "DATABASE";
    private static final int DATABASE_VERSION = 1;
    private static String DATABASE_NAME = "Events.db";

    private static final String EVENTS_TABLE = "Events_Table";

    public static final String col_id = "id";
    public static final String col_title = "Event_name";
    public static final String col_type = "Event_type" ;
    public static final String col_location = "Event_loc";
    public static final String col_startDate = "Event_strtDate";




    public Database(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);

    }

    //Create Table
    @Override
    public void onCreate(SQLiteDatabase db) {

        String CREATE_TABLE_EVENTS = "CREATE TABLE " + EVENTS_TABLE + "("
                + col_id + " INTEGER PRIMARY KEY AUTOINCREMENT ,"
                + col_title + " TEXT, "
                + col_type + " TEXT, "
                + col_location + " TEXT, "
                + col_startDate + " TEXT,)";

        db.execSQL(CREATE_TABLE_EVENTS);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        // Drop older table if existed, all data will be gone!!!
        db.execSQL("DROP TABLE IF EXISTS " + EVENTS_TABLE);

        //CREATE TABLE AGAIN
        onCreate(db);
    }



    //Insert Data
    public boolean insertEventsData (String title, String type, String location, String startDate){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(col_title, title);
        values.put(col_type , type);
        values.put(col_location, location);
        values.put(col_startDate, startDate);

        long result = db.insert(EVENTS_TABLE, null, values);
        if (result == -1)
            return false;
        else
            return true;
    }



    //Insert Data2
    int insertEventData (EventDetails eventDetails){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(col_title, eventDetails.getEventTitle());
        values.put(col_type , eventDetails.getEventType());
        values.put(col_location, eventDetails.getEventLoc());
        values.put(col_startDate, eventDetails.getEventDate());

        long result = db.insert(EVENTS_TABLE, null, values);
        return (int)result;
    }


    //Retrive Data
    public Cursor getEventData(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor result = db.rawQuery("SELECT * FROM " + EVENTS_TABLE, null);

        return result;
    }


    //Retrive Data2
    public List<EventDetails> getAllEvents(){
        SQLiteDatabase db = this.getReadableDatabase();
        List<EventDetails> eventItems = new ArrayList<EventDetails>();

        String selectQ= "SELECT * FROM " + EVENTS_TABLE;
        Cursor cursor = db.rawQuery(selectQ, new String[] {});
        if(cursor.moveToFirst()){
            do{

                EventDetails eventDetails = new EventDetails();

                eventDetails.setID(Integer.parseInt(cursor.getString(0)));
                eventDetails.setEventTitle(cursor.getString(1));
                eventDetails.setEventType(cursor.getString(2));
                eventDetails.setEventLoc(cursor.getString(3));
                eventDetails.setEventDate(cursor.getString(4));

                eventItems.add(eventDetails);

            }while (cursor.moveToNext());
        }

        return eventItems;
    }


    //Update Event
    public long UpdateEventData (EventDetails eventDetails){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(col_title, eventDetails.getEventTitle());
        values.put(col_type , eventDetails.getEventType());
        values.put(col_location, eventDetails.getEventLoc());
        values.put(col_startDate, eventDetails.getEventDate());


        //Get the ID for Update.
        return db.update(EVENTS_TABLE,values, col_id + " = ?",
                new String[] {String.valueOf(eventDetails.getID())});
    }

    //Update Event2
    public void updateEvent (int id, String newTitle, String newType, String newLoc, String newDate,
                             String oldTitle, String oldType, String oldLoc, String oldDate)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        String updateQuery = "Update " + EVENTS_TABLE + "SET " + col_title + " = '" + newTitle + "'" +
                col_type + " = '"  + newType +  "'" +
                col_location + " = '" + newLoc + "'" +
                col_startDate + " = '" + newDate +
                "' WHERE " + col_id + " = '" + id +
                "'" + " AND " + col_title + " = '" + oldTitle + "'" + " AND " +
                col_type + " = '"  + oldType + "'" + " AND " +
                col_location + " = '" + oldLoc + "'" + " AND " +
                col_startDate + " = '" + oldDate + "'";

        Log.d(TAG,"Update Event" + updateQuery );
        Log.d(TAG, "update Event: setting new Event to " + newTitle + newType + newLoc + newDate);

        db.execSQL(updateQuery);



    }




    //Retrive EventId
    public Cursor getEventID(String name){

        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT " + col_id + "FROM " + EVENTS_TABLE +
                "WHERE " + col_title + " = '" + name + "'";

        Cursor data = db.rawQuery(query, null);
        return data;


    }



    //Delete Data
    public void deleteEvent (EventDetails eventDetails){
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(EVENTS_TABLE, col_id + " = ?",
                new String[] {String.valueOf(eventDetails.getID())});
        Log.d(TAG, "Delete Event: Deleting  Event ");

    }


    //Delete Data2
    public void deleteEvent2 (int id){
        SQLiteDatabase db = this.getWritableDatabase();
        String deleteQuery = col_id + "= " + id;

        Log.d(TAG,"Delete Event" + deleteQuery );
        Log.d(TAG, "Delete Event: Deleting  Event " + id);

        db.delete(EVENTS_TABLE, deleteQuery, null);

    }


    //Delete Data3
    public void deleteEvent3 (int id, String name){
        SQLiteDatabase db =this.getWritableDatabase();
        String query = "DELETE FROM " + EVENTS_TABLE + "WHERE "
                + col_id + " ='" + id + "'" + "AND "
                + col_title + " = '" + name + "'";

        Log.d(TAG,"Delete Event" + query );
        Log.d(TAG, "Delete Event: Deleting  Event " + name);

        db.execSQL(query);

    }




}









