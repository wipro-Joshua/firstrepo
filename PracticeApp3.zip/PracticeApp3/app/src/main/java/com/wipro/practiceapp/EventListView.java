package com.wipro.practiceapp;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class EventListView extends AppCompatActivity {


    Database db;
    private EventListAdapter adapter;
    private List<EventDetails> eventlist;
    private ListView eventResultsListView;
    EventDetails eventDetails;

    private final static String TAG = "EventListView";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);
        Log.d(TAG, "onCreate: Started.");


        eventResultsListView = (ListView) findViewById(R.id.list_EventsView);

        db = new Database(this);

        //Display Events
        eventlist = db.getAllEvents();
        adapter = new EventListAdapter(this, eventlist);
        eventResultsListView.setAdapter(adapter);

        SelectItem();

    }

    //Select Item
    public void SelectItem (){
        eventResultsListView.setOnItemClickListener( new AdapterView.OnItemClickListener(){

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id)

            {



                EventDetails eventDetails = eventlist.get(position);

                //Get EventTitle
                String name = eventDetails.getEventTitle();

                //Pass Title to cursor for update

                Intent editEventScreen = new Intent(EventListView.this, DisplayEventScreen.class);
                // editEventScreen.putExtra("ID", itemID);
                editEventScreen.putExtra("Title", name);
                editEventScreen.putExtra("Type", eventDetails.getEventType());
                editEventScreen.putExtra("Loc", eventDetails.getEventLoc());
                editEventScreen.putExtra("Date", eventDetails.getEventDate());
                startActivity(editEventScreen);

            }
        });
    }

}




