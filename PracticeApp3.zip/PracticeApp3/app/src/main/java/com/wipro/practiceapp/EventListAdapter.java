package com.wipro.practiceapp;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;

/**
 * Created by JO391061 on 09/10/2017.
 */

class EventListAdapter extends BaseAdapter {

    private LayoutInflater myInflater;
    private Activity activity;
    private List<EventDetails> eventsDetails;



    public EventListAdapter(Activity activity, List<EventDetails> details){
        this.activity = activity;
        this.eventsDetails = details;

    }

    @Override
    public int getCount(){
        return eventsDetails.size();
    }

    @Override
    public Object getItem(int position){
        return eventsDetails.get(position);
    }

    @Override
    public long getItemId(int position){
        return position;
    }

    @Override
    public View getView (int position, View convertView, ViewGroup parents){

        //if(myInflater == null)
        myInflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        //if(convertView == null)
        convertView = myInflater.inflate(R.layout.event_adapter_view_layout, null);

        //Get the veiw

        TextView eventTitle = (TextView) convertView.findViewById(R.id.text_EventLTitle);
        TextView eventType = (TextView) convertView.findViewById(R.id.text_EventLType);
        TextView eventLoc = (TextView) convertView.findViewById(R.id.text_EventLoc);
        TextView eventDate = (TextView) convertView.findViewById(R.id.text_EventDate);

        // Button delete = (Button) convertView.findViewById(R.id.delete);
        // Button Edit = (Button) convertView.findViewById(R.id.edit);


        EventDetails evd = eventsDetails.get(position);


        //Set the Data
        eventTitle.setText(evd.getEventTitle());
        eventType.setText(evd.getEventType());
        eventLoc.setText(evd.getEventLoc());
        eventDate.setText(evd.getEventDate());


        //delete.setOnClickListener(new ListItemClickListener(position, evd));
        // Edit.setOnClickListener(new ListItemClickListener());

            /*if(eventTitle != null){
                eventTitle.setText((evd.getEventTitle()));
            }
            if(eventType != null){
                eventType.setText((evd.getEventType()));
            }
            if(eventLoc != null){
                eventLoc.setText((evd.getEventLoc()));
            }
            if(eventDate != null){
                eventDate.setText((evd.getEventDate()));
            }

        }*/
        return convertView;
    }


    /*public class ListItemClickListener implements View.OnClickListener {

        int position;
        EventDetails details;

        public ListItemClickListener(int position, EventDetails details){
            this.position = position;
            this.details = details;
        }

        @Override
        public void onClick(View v) {

            Database db = new Database (activity);
            db.deleteEvent(details);
            eventsDetails.remove(position);
            notifyDataSetChanged();
        }


        }*/
}


