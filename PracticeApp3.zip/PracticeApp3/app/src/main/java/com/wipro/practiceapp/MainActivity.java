package com.wipro.practiceapp;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {


    //The DATABASE
    Database db;

    //The Custom Adapter
    EventListAdapter adapter;

    //The listview Items
    List<EventDetails> eventList;

    //For Degbugging
    private final static String TAG = "EventListView";


    //Fields for adding Data.
    EditText editTitle, editType, editLoc, editDate;

    //Navigation Buttons.
    Button btn_saveConEvent, btn_Submit, btn_test;
    TextView tvStatus;



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = new Database(this);



        //Buttons
        btn_saveConEvent = (Button)findViewById(R.id.scEvent_Btn);
        btn_Submit = (Button)findViewById(R.id.submitEvent_Btn);
        btn_test = (Button)findViewById(R.id.test_Btn);

        //Text FIELDS
        editTitle = (EditText) findViewById(R.id.eventTitle_editTxt);

        editType = (EditText) findViewById(R.id.eventType_editTxt);

        editLoc = (EditText) findViewById(R.id.location_editTxt);

        editDate = (EditText) findViewById(R.id.eventDate_editTxt);



        InsertEventData();
        goToViewEvents();


    }


    public void InsertEventData() {

        btn_saveConEvent.setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        boolean isInserted = db.insertEventsData(
                                editTitle.getText().toString(),
                                editType.getText().toString(),
                                editLoc.getText().toString(),
                                editDate.getText().toString());

                        if (isInserted = true) {
                            Toast.makeText(MainActivity.this, " Data Inserted - Save and Continue Later", Toast.LENGTH_LONG).show();
                            editTitle.setText("");
                            editType.setText("");
                            editLoc.setText("");
                            editDate.setText("");
                            Intent goToEvents = new Intent(MainActivity.this,EventListView.class );
                            startActivity(goToEvents);
                        }
                        else {
                            Toast.makeText(MainActivity.this, " Data not Inserted", Toast.LENGTH_LONG).show();
                        }

                    }
                }

        );


        btn_Submit.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                boolean isInserted = db.insertEventsData(
                        editTitle.getText().toString(),
                        editType.getText().toString(),
                        editLoc.getText().toString(),
                        editDate.getText().toString());

                if (isInserted = true) {
                    Toast.makeText(MainActivity.this, " Data Inserted Successfully", Toast.LENGTH_LONG).show();
                    editTitle.setText("");
                    editType.setText("");
                    editLoc.setText("");
                    editDate.setText("");
                    Intent goToEvents = new Intent(MainActivity.this,EventListView.class );
                    startActivity(goToEvents);
                }
                else {
                    Toast.makeText(MainActivity.this, " Data not Inserted", Toast.LENGTH_LONG).show();
                }
            }
        });





    }

    //Testing the chooseEvent Screen
    public void goToViewEvents(){
        btn_test.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goToEvents = new Intent(MainActivity.this,EventListView.class );
                startActivity(goToEvents);
            }
        });
    }

}