package com.wipro.wicruit;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AdminCheck extends AppCompatActivity {

    DatabaseClass myDB;
    EditText Password;
    Button Submit;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_check);

        myDB = new DatabaseClass(this);



        Submit = (Button) findViewById(R.id.LoginBtn);
        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final EditText Password = (EditText) findViewById(R.id.PasswordEt);
                String PasswordText = Password.getText().toString();

                if (myDB.ReturnToEventsHome(PasswordText) == true) {

                    Intent intent = new Intent(AdminCheck.this, EventsHome.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(AdminCheck.this, "Password is incorrect", Toast.LENGTH_LONG).show();
                }

            }
        });


    }

}
