package com.wipro.wicruit;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import static android.R.id.list;

/**
 * Created by JO391061 on 08/10/2017.
 */

public class DisplayEventScreen extends AppCompatActivity {

    private static final String TAG = "DisplayEventScreen";

    DatabaseClass db;
    EventDetails details;

    static String Title;

    EventListAdapter adapter;
    List<EventDetails> eventlist ;
    private ListView listView;

    TextView title_text;
    EditText rTitle, rType, rLoc, rDate, rStatus;

    //Set String
    String s_Title, s_Type, s_Loc, s_date, s_Status;
    Button btn_delete, btn_edit, btn_goToEventsHome, btn_ViewReport;

    //ID
    private int selectedID;
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.display_events_activity);

        // Set Text Views
        title_text = (TextView)findViewById(R.id.TitleTEXT);
        rTitle = (EditText) findViewById(R.id.recevied_Title);
        rType = (EditText)findViewById(R.id.recevied_Type);
        rLoc = (EditText)findViewById(R.id.recevied_Loc);
        rDate = (EditText)findViewById(R.id.recevied_Date);
        //rStatus = (TextView)findViewById(R.id.recevied_Title);

        //Set Buttons
        btn_delete = (Button)findViewById(R.id.btn_DELETE);
        btn_edit = (Button)findViewById(R.id.btn_edit);

        btn_ViewReport = (Button)findViewById(R.id.btn_ViewReport);
        btn_goToEventsHome = (Button)findViewById(R.id.btn_EventsHome);

        //Open Database Connection
        db = new DatabaseClass(this);

        Intent intent = getIntent();
        s_Title = intent.getStringExtra("Title");
        s_Type = intent.getStringExtra("Type");
        s_Loc = intent.getStringExtra("Loc");
        s_date = intent.getStringExtra("Date");

        //Set Data
        title_text.setText(s_Title);
        rTitle.setText(s_Title);
        rType.setText(s_Type);
        rLoc.setText(s_Loc);
        rDate.setText(s_date);
        // rStatus.setText();

        btn_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                rTitle = (EditText) findViewById(R.id.recevied_Title);
                Title = rTitle.getText().toString();

                rType = (EditText)findViewById(R.id.recevied_Type);
                String Type = rType.getText().toString();

                rLoc = (EditText)findViewById(R.id.recevied_Loc);
                String Location = rLoc.getText().toString();

                rDate = (EditText)findViewById(R.id.recevied_Date);
                String Date = rDate.getText().toString();

                if(Title.isEmpty() || Type.isEmpty() || Location.isEmpty() || Date.isEmpty()){
                    ToastMessage("Please Fill all fields");
                }else {
                    db.updateEvent(Title, Type, Location, Date, "Complete");
                    Intent eventsScreen = new Intent(DisplayEventScreen.this, EventsHome.class);
                    startActivity(eventsScreen);
                    ToastMessage("Event has been updated");
                }
            }
        });

        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                rTitle = (EditText) findViewById(R.id.recevied_Title);
                Title = rTitle.getText().toString();

                if(db.deleteEvent(Title) == true)
                    ToastMessage("Cannot Delete an event which is in progress");
                else
                {
                    ToastMessage("Event Deleted");
                    Intent eventsScreen = new Intent(DisplayEventScreen.this, EventsHome.class);
                    startActivity(eventsScreen);
                }
            }
        });




        // add view event page here...
        btn_ViewReport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name = details.getEventTitle();


                Intent viewStudents = new Intent(DisplayEventScreen.this, ViewStudentData.class);
                viewStudents.putExtra("Title", name);

                db.getStudent(name);
                startActivity(viewStudents);
            }
        });

        btn_goToEventsHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent eventsScreen = new Intent(DisplayEventScreen.this, EventsHome.class);
                startActivity(eventsScreen);
            }
        });

    }
    public void ToastMessage(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
