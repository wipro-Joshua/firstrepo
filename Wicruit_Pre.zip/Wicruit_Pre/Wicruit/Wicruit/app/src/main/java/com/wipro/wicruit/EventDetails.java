package com.wipro.wicruit;

/**
 * Created by JO391061 on 09/10/2017.
 */

public class EventDetails {

    int ID;
    String eventTitle;
    String eventType;
    String eventLoc;
    String eventDate;
    String eventStatus;
    String eventAtt;


    public EventDetails() {

    }


    public EventDetails(int id, String eventTitle, String eventType,
                        String eventLoc, String eventDate, String eventStatus) {

        this.ID = id;
        this.eventTitle = eventTitle;
        this.eventType = eventType;
        this.eventLoc = eventLoc;
        this.eventDate = eventDate;
        this.eventStatus = eventStatus;
    }


    public EventDetails(String eventTitle, String eventType,
                        String eventLoc, String eventDate, String eventStatus) {
        this.eventTitle = eventTitle;
        this.eventType = eventType;
        this.eventLoc = eventLoc;
        this.eventDate = eventDate;
        this.eventStatus = eventStatus;
    }


    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getEventTitle() {
        return eventTitle;
    }

    public void setEventTitle(String eventTitle) {
        this.eventTitle = eventTitle;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getEventLoc() {
        return eventLoc;
    }

    public void setEventLoc(String eventLoc) {
        this.eventLoc = eventLoc;
    }

    public String getEventDate() {
        return eventDate;
    }

    public void setEventDate(String eventDate) {
        this.eventDate = eventDate;
    }

    public String getEventStatus() {
        return eventStatus;
    }
    public void setEventStatus(String eventStatus) {
        this.eventStatus = eventStatus;
    }

    public String getEventAtt() {
        return eventAtt;
    }

    public void setEventAtt(String eventAtt) {
        this.eventAtt = eventAtt;
    }
}