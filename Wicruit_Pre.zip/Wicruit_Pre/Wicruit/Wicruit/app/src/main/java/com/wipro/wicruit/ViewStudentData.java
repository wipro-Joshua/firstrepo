package com.wipro.wicruit;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import de.codecrafters.tableview.TableView;
import de.codecrafters.tableview.listeners.OnScrollListener;
import de.codecrafters.tableview.listeners.TableDataClickListener;
import de.codecrafters.tableview.toolkit.SimpleTableDataAdapter;
import de.codecrafters.tableview.toolkit.SimpleTableHeaderAdapter;

public class ViewStudentData extends AppCompatActivity {

    DatabaseClass databaseHelper = new DatabaseClass(this);
    //SingleStudentData SingleStudentData = new SingleStudentData();

    String s_Title;

    private static String[][] Student = { };
    private static final String[] Header = { "First name", "Second Name", "Course", "Passport" };

    public ViewStudentData() {};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_student_data);


        Intent intent = getIntent();
        s_Title = intent.getStringExtra("Title");;


        TableView<String[]> tableView = (TableView<String[]>) findViewById(R.id.tableView);

        Student = populateStudent();

        tableView.setHeaderAdapter(new SimpleTableHeaderAdapter(this, Header));
        tableView.setDataAdapter(new SimpleTableDataAdapter(this, Student));

        tableView.addDataClickListener(new TableDataClickListener() {
            @Override
            public void onDataClicked(int rowIndex, Object clickedData) {
                Log.d("PKA1", "view student data passing name");
                String name = ((String[])clickedData)[1];
                String lname = ((String[])clickedData)[2];
                //SingleStudentData.setName1(name);
                //Update a specific table with the required string
                Log.d("PKA1", "before parameter");
                Log.d("PKA1", name + "" + lname);
                //databaseHelper.insertStudentName(name, lname);
                //databaseHelper.insertData(name, name);

                Log.d("PKA1", "after parameter" + name);
                Intent successLogin = new Intent(ViewStudentData.this, SingleStudentData.class);
                startActivity(successLogin);
                Toast.makeText(ViewStudentData.this, ((String[])clickedData)[1], Toast.LENGTH_SHORT).show();

            }
        });
    }

    private class MyOnScrollListener implements OnScrollListener {
        @Override
        public void onScroll(final ListView tableDataView, final int firstVisibleItem, final int visibleItemCount, final int totalItemCount) {
            // listen for scroll changes
        }

        @Override
        public void onScrollStateChanged(final ListView tableDateView, final ScrollState scrollState) {
            // listen for scroll state changes
        }
    }

    private String[][] populateStudent(){



        ArrayList<String> st1 = databaseHelper.getStudent(s_Title);
        // Log.d("test", "test");
        int noofStudents = (st1.size())/4;
        int index = 0, j=0;
        String studentData[][] = new String[noofStudents][10];
        for (String student : st1){
            //    Log.d("PKA1", "value of j is " +j);
            if(index != 4) {
                studentData[j][index] = student;
                //        Log.d("PKA1", student);
                index++;
            }
            else {
                j++;
                index = 0;
            }
        }
        return  studentData;

    }

    public String StudentName(String  name){
        return name;
    }

}
