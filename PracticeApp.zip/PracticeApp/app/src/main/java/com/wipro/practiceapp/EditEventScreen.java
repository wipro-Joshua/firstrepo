package com.wipro.practiceapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by JO391061 on 08/10/2017.
 */

public class EditEventScreen extends AppCompatActivity {


    private static final String TAG = "EditEventScreen";

    private Button btnDelete, btnSave;
    private EditText editEventTitle, editEventType, editEventLoc, editEventDate;

    Database db;

    private String selectedEventTitle, selectedEventType, selectedEventLoc, selectedEventDate;
    private int selectedID;

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_events);
        btnDelete = (Button) findViewById(R.id.event_delete);
        btnSave = (Button) findViewById(R.id.event_save);
        editEventTitle = (EditText) findViewById(R.id.edit_eventTitle);
        editEventType = (EditText) findViewById(R.id.edit_eventType);
        editEventLoc = (EditText) findViewById(R.id.edit_eventLoc);
        editEventDate = (EditText) findViewById(R.id.edit_eventDate);
        db = new Database(this);


        Intent receivedIntent = getIntent();

        selectedID = receivedIntent.getIntExtra("id", -1);
        selectedEventTitle = receivedIntent.getStringExtra("event_title");
        selectedEventType = receivedIntent.getStringExtra("event_type");
        selectedEventLoc = receivedIntent.getStringExtra("event_loc");
        selectedEventDate = receivedIntent.getStringExtra("event_date");

        editEventTitle.setText(selectedEventTitle);
        editEventType.setText(selectedEventType);
        editEventLoc.setText(selectedEventLoc);
        editEventDate.setText(selectedEventDate);


        saveEvent();
        deleteEvent();


    }

        public void saveEvent(){btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Get Data and Update
                String eventTitle = editEventTitle.getText().toString();
                String eventType = editEventType.getText().toString();
                String eventLoc = editEventLoc.getText().toString();
                String eventDate = editEventDate.getText().toString();
                if (eventTitle.equals("")) {
                    db.updateEvent(eventTitle, eventType, eventLoc, eventDate, selectedID, selectedEventTitle, selectedEventType, selectedEventLoc, selectedEventDate);


                } else {
                    ToastMessage("Please Enter Detail");
                }
            }
        });
        }



        public void deleteEvent(){
            btnDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    db.deleteEvent(selectedID, selectedEventTitle);
                    editEventTitle.setText("");
                    ToastMessage("Deleted");

                }
            });
        }


    public void ToastMessage(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
