package com.wipro.practiceapp;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainEventScreen extends AppCompatActivity {

    private static final String TAG = "ListEvents";
    private ListView eventList;
    Database db;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_event_screen);
        eventList = (ListView)findViewById(R.id.listView_Events);

        db = new Database(this);


        loadListEvents();
    }


    private void loadListEvents(){
        Log.d(TAG, "Populate Event Data in ListView");

        Cursor eventData = db.getEventData();
        ArrayList<String> eventsDataList = new ArrayList<>();
        while (eventData.moveToNext()){
            eventsDataList.add(eventData.getString(1));
        }
        ListAdapter adapterL = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, eventsDataList);
        eventList.setAdapter(adapterL);

        //Navigate to Edit Screen
        eventList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                  String eventName = adapterView.getItemAtPosition(i).toString();
                  String eventType = adapterView.getItemAtPosition(i).toString();
                  String eventLoc = adapterView.getItemAtPosition(i).toString();
                  String eventDate = adapterView.getItemAtPosition(i).toString();
                  Log.d(TAG, "OnItemClick, you clicked on " + eventName);

                Cursor data = db.getEventID(eventName);
                int itemID = -1;
                while (data.moveToNext()){
                    itemID = data.getInt(0);
                }
                if (itemID > -1){
                    Log.d(TAG, "onItemClick: The ID is: " + itemID);
                    Intent editEventScreen = new Intent(MainEventScreen.this, EditEventScreen.class);
                    editEventScreen.putExtra("id", itemID);
                    editEventScreen.putExtra("event_title", eventName);

                    startActivity(editEventScreen);

                }
                else {
                    ToastMessage("There is no ID associated with that Event");
                }


            }
        });

    }


    public void ToastMessage(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

}
