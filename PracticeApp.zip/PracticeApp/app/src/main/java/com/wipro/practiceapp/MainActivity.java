package com.wipro.practiceapp;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    Database db;

    EditText editTitle, editType, editLoc, editDate;
    Button btn_saveConEvent, btn_Submit, btn_test;



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = new Database(this);

        //Buttons
        btn_saveConEvent = (Button)findViewById(R.id.scEvent_Btn);
        btn_Submit = (Button)findViewById(R.id.submitEvent_Btn);
        btn_test = (Button)findViewById(R.id.test_Btn);


        // View report button !!!!!!! btn_VeiwReport  =


        //Text FIELDS
        editTitle = (EditText) findViewById(R.id.eventTitle_editTxt);
        editType = (EditText) findViewById(R.id.eventType_editTxt);
        editLoc = (EditText) findViewById(R.id.location_editTxt);
        editDate = (EditText) findViewById(R.id.eventDate_editTxt);
        InsertEventData();
        goToViewEvents();


    }


    public void InsertEventData() {

        btn_saveConEvent.setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        boolean isInserted = db.insertEventData(editTitle.getText().toString(),
                                editType.getText().toString(),
                                editLoc.getText().toString(),
                                editDate.getText().toString());

                        if (isInserted = true)
                            Toast.makeText(MainActivity.this, " Data Inserted", Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(MainActivity.this, " Data not Inserted", Toast.LENGTH_LONG).show();

                        //Spinner evSpinner = (Spinner)findViewById(R.id.Event_Spinner);



                    }
                }
        );

    }

    //Testing the chooseEvent Screen
    public void goToViewEvents(){
        btn_test.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goToEvents = new Intent(MainActivity.this,MainEventScreen.class );
                startActivity(goToEvents);
            }
        });
}



    //!!!!!!!!!!

    /*public void veiwAllEventData(){
        btn_VeiwReport.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View v){

                     Cursor resuslt = db.getEventData();
                       if(resuslt.getCount() == 0){
                           // display message if no result.
                           showMessage("Error", "No Data Found");
                           return;
                       }

                       // Store results in string buffer
                       StringBuffer buffer = new StringBuffer();
                        while(resuslt.moveToNext()){
                            buffer.append("id :" + resuslt.getString(0) + "\n");
                            buffer.append("Event_name :" + resuslt.getString(1) + "\n");
                            buffer.append("Event_type :" + resuslt.getString(2) + "\n");
                            buffer.append("Event_loc :" + resuslt.getString(3) + "\n");
                            buffer.append("Event_strtDate :" + resuslt.getString(4) + "\n\n");

                        }

                        //Show all Data
                        showMessage("Data", buffer.toString());
                    }
                }
        );
    }

    public void showMessage (String title, String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
*/

}

