package com.wipro.practiceapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.nfc.Tag;
import android.util.Log;

import java.util.ArrayList;

/**
 * Created by JO391061 on 05/10/2017.
 */

public class Database extends SQLiteOpenHelper{

    private static final String TAG = "DATABASE";


    private static final int DATABASE_VERSION = 1;
    private static String DATABASE_NAME = "Events.db";

    private static final String EVENTS_TABLE = "Events_Table";

    public static final String col_id = "id";
    public static final String col_title = "Event_name";
    public static final String col_type = "Event_type" ;
    public static final String col_location = "Event_loc";
    public static final String col_startDate = "Event_strtDate";




    public Database(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);

    }


//Create Table
    @Override
    public void onCreate(SQLiteDatabase db) {



        String CREATE_TABLE_EVENTS = "CREATE TABLE " + EVENTS_TABLE + "("
                + col_id + " INTEGER PRIMARY KEY AUTOINCREMENT ,"
                + col_title + " TEXT, "
                + col_type + " TEXT, "
                + col_location + " TEXT, "
                + col_startDate + " TEXT)";

        db.execSQL(CREATE_TABLE_EVENTS);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        // Drop older table if existed, all data will be gone!!!
        db.execSQL("DROP TABLE IF EXISTS " + EVENTS_TABLE);

        //CREATE TABLE AGAIN
        onCreate(db);
    }


    //Insert Data
    public boolean insertEventData (String title, String type, String location, String startDate){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(col_title, title);
        values.put(col_type , type);
        values.put(col_location, location);
        values.put(col_startDate, startDate);

        long result = db.insert(EVENTS_TABLE, null, values);
        if (result == -1)
                return false;
            else
                return true;
        }


    //Retrive Data
    public Cursor getEventData(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor result = db.rawQuery("SELECT * FROM " + EVENTS_TABLE, null);

        return result;
 }

    //Retrive Data 2
    public ArrayList<String> getEventDataAll(){
        ArrayList<String> list = new ArrayList<String>();
        SQLiteDatabase db = this.getReadableDatabase();
        db.beginTransaction();
       try{
        String selectQuery = "SELECT * FROM " + EVENTS_TABLE;
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.getCount() > 0){
            while (cursor.moveToNext()){
                String ctitle = cursor.getString(cursor.getColumnIndex("Event_name"));
                list.add(ctitle);
            }
        }
        db.setTransactionSuccessful();

    } catch (Exception e) {
             e.printStackTrace();
    }
    finally {
          db.endTransaction();
           db.close();

       }
       return list;
    }


    //Get Item ID
    public Cursor getEventID(String title){
        SQLiteDatabase db = this.getWritableDatabase();
        String selectQuery1 = "SELECT " + col_id + "FROM " + EVENTS_TABLE +
                               "WHERE " + col_type + " = '" + title + "'";
        Cursor data = db.rawQuery(selectQuery1, null);
        return data;


    }

    //Update Event
    public void updateEvent (String newTitle, String newType, String newLoc, String newDate, int id,
                             String oldTitle, String oldType, String oldLoc, String oldDate)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        String updateQuery = "Update " + EVENTS_TABLE + "SET " + col_title + " = '" + newTitle + "'" +
                                                                 col_type + " = '"  + newType +  "'" +
                                                                 col_location + " = '" + newLoc + "'" +
                                                                  col_startDate + " = '" + newDate +
                              "' WHERE " + col_id + " = '" + id +
                              "'" + " AND " + col_title + " = '" + oldTitle + "'" + " AND " +
                col_type + " = '"  + oldType + "'" + " AND " +
                col_location + " = '" + oldLoc + "'" + " AND " +
                col_startDate + " = '" + oldDate + "'";

        Log.d(TAG,"Update Event" + updateQuery );
        Log.d(TAG, "update Event: setting new Event to " + newTitle + newType + newLoc + newDate);

        db.execSQL(updateQuery);



    }


    //Delete Data
    public void deleteEvent (int id, String title){
        SQLiteDatabase db = this.getWritableDatabase();
        String deleteQuery = "DELETE FROM " + EVENTS_TABLE + "WHERE " + col_id + "= '" + id + "'"
                              + "AND " + col_title + "= '" + title + "'";

        Log.d(TAG,"Delete Event" + deleteQuery );
        Log.d(TAG, "Delete Event: Deleting  Event " + id + title);

        db.execSQL(deleteQuery);

    }


    }









