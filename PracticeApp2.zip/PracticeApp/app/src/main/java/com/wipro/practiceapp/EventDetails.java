package com.wipro.practiceapp;

/**
 * Created by JO391061 on 09/10/2017.
 */

public class EventDetails {

    private String eventTitle;
    private String eventType;
    private String eventLoc;
    private String eventDate;

    public EventDetails(String eventTitle, String eventType,
                        String eventLoc, String eventDate) {
        this.eventTitle = eventTitle;
        this.eventType = eventType;
        this.eventLoc = eventLoc;
        this.eventDate = eventDate;
    }


    public String getEventTitle() {
        return eventTitle;
    }

    public void setEventTitle(String eventTitle) {
        this.eventTitle = eventTitle;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getEventLoc() {
        return eventLoc;
    }

    public void setEventLoc(String eventLoc) {
        this.eventLoc = eventLoc;
    }

    public String getEventDate() {
        return eventDate;
    }

    public void setEventDate(String eventDate) {
        this.eventDate = eventDate;
    }


}
