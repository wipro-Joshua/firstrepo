package com.wipro.practiceapp;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class EventListView extends AppCompatActivity {

    Database db;
    ArrayList<EventDetails> eventlist;
    ListView eventResultsListView;
    EventDetails eventDetails;

    private int selectedID;

    private static final String TAG = "EventListView";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list_view);
        Log.d(TAG, "onCreate: Started.");

        db = new Database(this);
        eventlist = new ArrayList<>();

        Cursor data = db.getEventData();
        // number of rows stored be stored in database
        int numRows = data.getCount();
        if(numRows == 0){

            Toast.makeText(EventListView.this, "Database is Empty", Toast.LENGTH_LONG).show();
        }
        else {
            //Get the column data into arrayList
            while (data.moveToNext()){
                eventDetails = new EventDetails(data.getString(1), data.getString(2), data.getString(3), data.getString(4));
                eventlist.add(eventDetails);
            }
            EventListAdapter adapter = new EventListAdapter(this, R.layout.event_adapter_view_layout, eventlist);
            eventResultsListView = (ListView)findViewById(R.id.list_EventsView);
            eventResultsListView.setAdapter(adapter);
            registerForContextMenu(eventResultsListView);

            SelectItem();
        }

    }
    //Create Context Menu

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_events_context_menu, menu);
    }

    //Delete Item

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();


        switch (item.getItemId())
        {
            case R.id.delete_ID:
                selectedID = info.position;
                eventlist.remove(info.position);
                db.deleteEvent(selectedID);
                Toast.makeText(EventListView.this, "EVENT DELETED", Toast.LENGTH_LONG).show();
        }

        return super.onContextItemSelected(item);
    }

    //Select Item
    public void SelectItem (){
        eventResultsListView.setOnItemClickListener( new AdapterView.OnItemClickListener(){

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {

                Intent editEventScreen = new Intent(EventListView.this, EditEventScreen.class);
                startActivity(editEventScreen);


            }
        });
    }
}
