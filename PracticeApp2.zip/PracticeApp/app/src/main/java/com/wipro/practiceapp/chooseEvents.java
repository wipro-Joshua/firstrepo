package com.wipro.practiceapp;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class chooseEvents extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    Database db;
    Button ok_btn;
    Spinner evSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_eventscreen);
        db = new Database(this);
        loadEventData();
 }

    public void loadEventData(){
     // View inserted data.
     ArrayList<String> listEvent = db.getEventDataAll();
     evSpinner = (Spinner)findViewById(R.id.Event_Spinner);
     ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.event_spinnerlayout, R.id.text_spinner, listEvent);
     evSpinner.setAdapter(adapter);

 }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
        String eSelected = parent.getItemAtPosition(pos).toString();
        Toast.makeText(this, eSelected, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
