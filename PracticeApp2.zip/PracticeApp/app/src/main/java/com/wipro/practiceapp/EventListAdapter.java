package com.wipro.practiceapp;

import android.content.Context;
import android.content.pm.ProviderInfo;
import android.support.annotation.IdRes;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by JO391061 on 09/10/2017.
 */

class EventListAdapter extends ArrayAdapter<EventDetails> {

    private LayoutInflater myInflater;
    private ArrayList<EventDetails> eventDetails;
    private int mVeiwEventID;



    public EventListAdapter(Context context, int tvResourceID, ArrayList<EventDetails> eventDetails){
        super(context, tvResourceID, eventDetails);

        this.eventDetails = eventDetails;
        myInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mVeiwEventID = tvResourceID;

    }

    public View getView (int position, View convertView, ViewGroup parents){

        convertView = myInflater.inflate(mVeiwEventID,null);

        EventDetails evd = eventDetails.get(position);

        if (evd != null ) {
            TextView eventTitle = (TextView) convertView.findViewById(R.id.text_EventLTitle);
            TextView eventType = (TextView) convertView.findViewById(R.id.text_EventLType);
            TextView eventLoc = (TextView) convertView.findViewById(R.id.text_EventLoc);
            TextView eventDate = (TextView) convertView.findViewById(R.id.text_EventDate);

            if(eventTitle != null){
                eventTitle.setText((evd.getEventTitle()));
            }
            if(eventType != null){
                eventType.setText((evd.getEventType()));
            }
            if(eventLoc != null){
                eventLoc.setText((evd.getEventLoc()));
            }
            if(eventDate != null){
                eventDate.setText((evd.getEventDate()));
            }

        }
        return convertView;
    }

}

