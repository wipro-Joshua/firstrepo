package com.wipro.wicruit;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ResetPassword extends AppCompatActivity {

    DatabaseClass db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);

        db = new DatabaseClass(this);
        //Reset Password Button
        Button ResetBtn = (Button)findViewById(R.id.resetPwdBtn);
        ResetBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ChangePassword();
            }
        });

    }
    private boolean ChangePassword()
    {
        EditText EmailId = (EditText)findViewById(R.id.EmailIdET);
        EditText Password = (EditText) findViewById(R.id.ResetPasswordET);
        EditText Password1 = (EditText) findViewById(R.id.ResetPassword1ET);

        String EmailId_Read = EmailId.getText().toString();
        String Password_Read = Password.getText().toString();
        String Password1_Read = Password1.getText().toString();

        if (EmailId_Read.isEmpty())
            Toast.makeText(this, "Enter Email ID", Toast.LENGTH_LONG).show();
        else if (Password1_Read.isEmpty() || Password_Read.isEmpty())
            Toast.makeText(this, "Enter Valid Password", Toast.LENGTH_LONG).show();
        else if(!(Password_Read.contentEquals(Password1_Read)))
            Toast.makeText(this, "Passwords entered do not match.\nTry again.", Toast.LENGTH_LONG).show();
        else    //Valid case
        {
          int ret = db.UpdateUserTable(EmailId_Read, Password_Read);
            if(ret == 1)        //If EmailID exists in DB
            {
                Toast.makeText(this, "Password was reset successfully.\n\nLogin Again. ", Toast.LENGTH_LONG).show();
                Intent BackToHomePage = new Intent(ResetPassword.this, MainActivity.class);
                startActivity(BackToHomePage);
            }
            else{
                Toast.makeText(this, "Email Does not exist in our Database.\nTry Again", Toast.LENGTH_LONG).show();
            }
        }
        return true;
    }

}


