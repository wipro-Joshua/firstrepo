package com.wipro.wicruit;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import java.util.ArrayList;

public class EndEvent extends AppCompatActivity {

    DatabaseClass myDB;
    Button endEvent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_end_event);

        myDB = new DatabaseClass(this);

        DatabaseClass databaseHelper = new DatabaseClass(this);

        ArrayList<String> listPro =databaseHelper.getEndAll();
        final Spinner sp = (Spinner)findViewById(R.id.endEventSp);

        ArrayAdapter<String> adapter= new ArrayAdapter<String>(this,R.layout.spinner_layout,R.id.txt,listPro);
        sp.setAdapter(adapter);

        final String EventEndTxt = "Event Ended";


        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(
                    AdapterView<?> adapterView, View view,
                    int i, long l) {
                final String ValueEnd = sp.getSelectedItem().toString();

                endEvent = (Button) findViewById(R.id.endEventBtn);


                endEvent.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        myDB.endEvent(EventEndTxt, ValueEnd);
                        Intent intent = new Intent(EndEvent.this, EventsHome.class);
                        startActivity(intent);
                    }
                });
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


    }
}
