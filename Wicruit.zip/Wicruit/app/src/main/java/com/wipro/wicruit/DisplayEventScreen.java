package com.wipro.wicruit;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import static android.R.id.list;

/**
 * Created by JO391061 on 08/10/2017.
 */

public class DisplayEventScreen extends AppCompatActivity {


    private static final String TAG = "DisplayEventScreen";

    DatabaseClass db;
    String pasID = null;
    EventDetails details;

    static String Title;


    EventListAdapter adapter;
    List<EventDetails> eventlist ;
    private ListView listView;



    TextView title_text, id_text;
    EditText rTitle, rType, rLoc, rDate, rStatus;

    //Set String
    String s_Title, s_Type, s_Loc, s_date, s_Status;
    Button btn_delete, btn_edit;

    //ID
    private int selectedID;


    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.display_events_activity);



        // Set Text Views
        title_text = (TextView)findViewById(R.id.TitleTEXT);
        id_text = (TextView)findViewById(R.id.id_Text);
        rTitle = (EditText) findViewById(R.id.recevied_Title);
        rType = (EditText)findViewById(R.id.recevied_Type);
        rLoc = (EditText)findViewById(R.id.recevied_Loc);
        rDate = (EditText)findViewById(R.id.recevied_Date);
        //rStatus = (TextView)findViewById(R.id.recevied_Title);



        //Set Buttons
        btn_delete = (Button)findViewById(R.id.btn_DELETE);
        btn_edit = (Button)findViewById(R.id.btn_edit);


        //Open Database Connection
        db = new DatabaseClass(this);

        Intent intent = getIntent();
        selectedID = intent.getIntExtra("ID", -1); //-1 is default value
        s_Title = intent.getStringExtra("Title");
        s_Type = intent.getStringExtra("Type");
        s_Loc = intent.getStringExtra("Loc");
        s_date = intent.getStringExtra("Date");


        //Set Data
        title_text.setText(s_Title);
        rTitle.setText(s_Title);
        rType.setText(s_Type);
        rLoc.setText(s_Loc);
        rDate.setText(s_date);
        // rStatus.setText();



        btn_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                rTitle = (EditText) findViewById(R.id.recevied_Title);
                Title = rTitle.getText().toString();


                rType = (EditText)findViewById(R.id.recevied_Type);
                String Type = rType.getText().toString();


                rLoc = (EditText)findViewById(R.id.recevied_Loc);
                String Location = rLoc.getText().toString();


                rDate = (EditText)findViewById(R.id.recevied_Date);
                String Date = rDate.getText().toString();




                if(Title.isEmpty() || Type.isEmpty() || Location.isEmpty() || Date.isEmpty()){
                    ToastMessage("Please Fill all fields");
                }else {
                    db.updateEvent(Title, Type, Location, Date);
                    ToastMessage("Event has been updated");
                }
            }
        });


        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                db.deleteEvent(Title);

                }
        });

    }

    public void ToastMessage(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
