package com.wipro.wicruit;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;

/**
 * Created by JO391061 on 09/10/2017.
 */

class EventListAdapter extends BaseAdapter {

    private LayoutInflater myInflater;
    private Activity activity;
    private List<EventDetails> eventsDetails;


    public EventListAdapter(Activity activity, List<EventDetails> details) {
        this.activity = activity;
        this.eventsDetails = details;

    }

    @Override
    public int getCount() {
        return eventsDetails.size();
    }

    @Override
    public Object getItem(int position) {
        return eventsDetails.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parents) {

        //if(myInflater == null)
        myInflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        //if(convertView == null)
        convertView = myInflater.inflate(R.layout.event_adapter_view_layout, null);

        //Get the veiw

        TextView eventTitle = (TextView) convertView.findViewById(R.id.text_EventLTitle);
        TextView eventType = (TextView) convertView.findViewById(R.id.text_EventLType);
        TextView eventLoc = (TextView) convertView.findViewById(R.id.text_EventLoc);
        TextView eventDate = (TextView) convertView.findViewById(R.id.text_EventDate);

        EventDetails evd = eventsDetails.get(position);


        //Set the Data
        eventTitle.setText(evd.getEventTitle());
        eventType.setText(evd.getEventType());
        eventLoc.setText(evd.getEventLoc());
        eventDate.setText(evd.getEventDate());

        return convertView;
    }


}


